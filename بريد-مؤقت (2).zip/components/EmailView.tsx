
import React from 'react';
import type { Email } from '../types';
import { MailOpenIcon, BackIcon } from './Icons';

interface EmailViewProps {
    email: Email | null;
    onBack: () => void;
}

const EmailView: React.FC<EmailViewProps> = ({ email, onBack }) => {
    if (!email) {
        return (
            <div className="hidden lg:flex flex-col items-center justify-center h-full bg-slate-800/50 border-2 border-dashed border-slate-700 rounded-xl text-slate-500 p-8">
                <MailOpenIcon className="w-20 h-20 mb-4" />
                <h3 className="text-xl font-semibold">حدد رسالة لعرضها</h3>
                <p>يتم عرض محتوى رسالتك هنا.</p>
            </div>
        );
    }

    return (
        <div className="bg-slate-800/50 border border-slate-700 rounded-xl shadow-lg flex flex-col h-full">
            <div className="flex items-center gap-4 p-4 border-b border-slate-700">
                <button onClick={onBack} className="lg:hidden p-2 rounded-full hover:bg-slate-700 transition-colors">
                    <BackIcon className="w-5 h-5" />
                </button>
                <div className="flex-grow">
                    <h2 className="text-xl font-bold text-white truncate">{email.subject}</h2>
                    <p className="text-sm text-slate-400 truncate">من: {email.from}</p>
                </div>
            </div>
            <div className="flex-grow p-6 overflow-y-auto">
                <p className="text-slate-300 whitespace-pre-wrap leading-relaxed">{email.body}</p>
            </div>
        </div>
    );
};

export default EmailView;
