
import React from 'react';
import { CopyIcon, RefreshIcon, LoadingSpinnerIcon } from './Icons';

interface EmailDisplayProps {
    email: string | null;
    isLoading: boolean;
    onCopy: () => void;
    onRefresh: () => void;
}

const EmailDisplay: React.FC<EmailDisplayProps> = ({ email, isLoading, onCopy, onRefresh }) => {
    return (
        <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 shadow-lg">
            <label className="block text-sm font-medium text-slate-400 mb-2">عنوان بريدك الإلكتروني المؤقت:</label>
            <div className="flex flex-col sm:flex-row items-center gap-4">
                <div className="w-full sm:flex-1 h-14 flex items-center justify-center bg-slate-900 rounded-md border border-slate-600 px-4">
                    {isLoading ? (
                        <div className="flex items-center gap-2 text-slate-500">
                             <LoadingSpinnerIcon className="w-5 h-5 animate-spin" />
                             <span>جاري الإنشاء...</span>
                        </div>
                    ) : (
                        <span className="text-lg font-mono text-cyan-300 select-all" dir="ltr">
                            {email}
                        </span>
                    )}
                </div>
                <div className="flex items-center gap-2 w-full sm:w-auto">
                    <button
                        onClick={onCopy}
                        disabled={isLoading || !email}
                        className="w-1/2 sm:w-auto flex items-center justify-center gap-2 bg-cyan-600 hover:bg-cyan-700 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-md transition-all duration-200"
                    >
                        <CopyIcon className="w-5 h-5" />
                        <span>نسخ</span>
                    </button>
                    <button
                        onClick={onRefresh}
                        disabled={isLoading}
                        className="w-1/2 sm:w-auto flex items-center justify-center gap-2 bg-slate-600 hover:bg-slate-700 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-md transition-all duration-200"
                    >
                        {isLoading ? <LoadingSpinnerIcon className="w-5 h-5 animate-spin"/> : <RefreshIcon className="w-5 h-5" />}
                        <span>جديد</span>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default EmailDisplay;
