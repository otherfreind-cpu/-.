
import React from 'react';
import type { Email } from '../types';
import { InboxIcon, RefreshIcon, TrashIcon, LoadingSpinnerIcon } from './Icons';

interface InboxProps {
    emails: Email[];
    isRefreshing: boolean;
    onSelectEmail: (email: Email) => void;
    onDeleteEmail: (emailId: string) => void;
    selectedEmailId?: string | null;
    onRefresh: () => void;
}

const Inbox: React.FC<InboxProps> = ({ emails, isRefreshing, onSelectEmail, onDeleteEmail, selectedEmailId, onRefresh }) => {
    
    const timeAgo = (dateString: string) => {
        const date = new Date(dateString);
        const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
        let interval = seconds / 31536000;
        if (interval > 1) return `منذ ${Math.floor(interval)} سنة`;
        interval = seconds / 2592000;
        if (interval > 1) return `منذ ${Math.floor(interval)} شهر`;
        interval = seconds / 86400;
        if (interval > 1) return `منذ ${Math.floor(interval)} يوم`;
        interval = seconds / 3600;
        if (interval > 1) return `منذ ${Math.floor(interval)} ساعة`;
        interval = seconds / 60;
        if (interval > 1) return `منذ ${Math.floor(interval)} دقيقة`;
        return 'الآن';
    };

    return (
        <div className="bg-slate-800/50 border border-slate-700 rounded-xl shadow-lg h-full flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-slate-700">
                <h2 className="text-xl font-bold text-white">البريد الوارد</h2>
                <button onClick={onRefresh} disabled={isRefreshing} className="p-2 rounded-full hover:bg-slate-700 transition-colors">
                    {isRefreshing ? <LoadingSpinnerIcon className="w-5 h-5 animate-spin" /> : <RefreshIcon className="w-5 h-5" />}
                </button>
            </div>
            <div className="flex-grow overflow-y-auto">
                {emails.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full p-8 text-center text-slate-400">
                        <InboxIcon className="w-16 h-16 text-slate-500 mb-4" />
                        <h3 className="font-semibold text-lg">صندوق بريدك فارغ</h3>
                        <p className="text-sm">سيتم عرض الرسائل الجديدة هنا تلقائيًا.</p>
                    </div>
                ) : (
                    <ul>
                        {emails.map(email => (
                            <li key={email.id}
                                className={`cursor-pointer border-b border-slate-700 ${selectedEmailId === email.id ? 'bg-cyan-900/50' : 'hover:bg-slate-700/50'}`}>
                                <div className="flex items-start gap-2 p-4">
                                  <div onClick={() => onSelectEmail(email)} className="flex-grow">
                                    <div className="flex justify-between items-baseline">
                                        <p className="font-semibold text-slate-200 truncate pr-2">{email.from}</p>
                                        <time className="text-xs text-slate-400 flex-shrink-0">{timeAgo(email.timestamp)}</time>
                                    </div>
                                    <p className="text-sm text-slate-300 mt-1 truncate">{email.subject}</p>
                                  </div>
                                  <button onClick={(e) => { e.stopPropagation(); onDeleteEmail(email.id); }} className="p-2 rounded-full hover:bg-red-500/20 text-slate-400 hover:text-red-400 flex-shrink-0 transition-colors">
                                    <TrashIcon className="w-4 h-4" />
                                  </button>
                                </div>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </div>
    );
};

export default Inbox;
