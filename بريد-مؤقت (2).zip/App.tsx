
import React, { useState, useEffect, useCallback } from 'react';
import type { Email } from './types';
import { generateAddress, fetchInbox } from './services/emailService';
import Header from './components/Header';
import EmailDisplay from './components/EmailDisplay';
import Inbox from './components/Inbox';
import EmailView from './components/EmailView';
import { LoadingSpinnerIcon } from './components/Icons';

const App: React.FC = () => {
    const [currentEmail, setCurrentEmail] = useState<string | null>(null);
    const [inbox, setInbox] = useState<Email[]>([]);
    const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
    const [isLoadingEmail, setIsLoadingEmail] = useState<boolean>(true);
    const [isRefreshingInbox, setIsRefreshingInbox] = useState<boolean>(false);
    const [notification, setNotification] = useState<string | null>(null);

    const showNotification = (message: string) => {
        setNotification(message);
        setTimeout(() => {
            setNotification(null);
        }, 3000);
    };

    const refreshInbox = useCallback(async (email: string) => {
        if (!email || isRefreshingInbox) return;
        setIsRefreshingInbox(true);
        try {
            const newEmails = await fetchInbox(email);
            if (newEmails.length > 0) {
                 setInbox(prevInbox => {
                    const existingIds = new Set(prevInbox.map(e => e.id));
                    const uniqueNewEmails = newEmails.filter(e => !existingIds.has(e.id));
                    if(uniqueNewEmails.length > 0) {
                        showNotification(`تم استلام ${uniqueNewEmails.length} رسالة جديدة`);
                    }
                    return [...uniqueNewEmails, ...prevInbox];
                });
            }
        } catch (error) {
            console.error("Error refreshing inbox:", error);
            showNotification("فشل في تحديث البريد الوارد");
        } finally {
            setIsRefreshingInbox(false);
        }
    }, [isRefreshingInbox]);

    const handleGenerateNewEmail = useCallback(async () => {
        setIsLoadingEmail(true);
        setSelectedEmail(null);
        setInbox([]);
        try {
            const newEmail = await generateAddress();
            setCurrentEmail(newEmail);
            showNotification("تم إنشاء عنوان بريد إلكتروني جديد");
            await refreshInbox(newEmail);
        } catch (error) {
            console.error("Error generating new email:", error);
            showNotification("فشل في إنشاء بريد إلكتروني جديد");
        } finally {
            setIsLoadingEmail(false);
        }
    }, [refreshInbox]);

    useEffect(() => {
        handleGenerateNewEmail();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        if (!currentEmail) return;
        const intervalId = setInterval(() => {
            refreshInbox(currentEmail);
        }, 15000); // Refresh every 15 seconds

        return () => clearInterval(intervalId);
    }, [currentEmail, refreshInbox]);
    
    const handleDeleteEmail = (emailId: string) => {
        setInbox(prev => prev.filter(e => e.id !== emailId));
        if (selectedEmail?.id === emailId) {
            setSelectedEmail(null);
        }
        showNotification("تم حذف الرسالة بنجاح");
    };

    return (
        <div className="min-h-screen bg-slate-900 text-slate-200 p-4 sm:p-6 lg:p-8">
            <div className="max-w-7xl mx-auto">
                <Header />
                <main className="mt-8">
                    <EmailDisplay
                        email={currentEmail}
                        isLoading={isLoadingEmail}
                        onCopy={() => {
                            if(currentEmail) {
                                navigator.clipboard.writeText(currentEmail);
                                showNotification("تم نسخ البريد الإلكتروني!");
                            }
                        }}
                        onRefresh={handleGenerateNewEmail}
                    />

                    {isLoadingEmail && !currentEmail ? (
                         <div className="flex flex-col items-center justify-center mt-20 text-center">
                            <LoadingSpinnerIcon className="w-12 h-12 animate-spin text-cyan-400" />
                            <p className="mt-4 text-lg text-slate-400">جاري إنشاء عنوان بريدك المؤقت...</p>
                        </div>
                    ) : (
                        <div className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
                           <div className="lg:col-span-4">
                                <Inbox
                                    emails={inbox}
                                    isRefreshing={isRefreshingInbox}
                                    onSelectEmail={setSelectedEmail}
                                    onDeleteEmail={handleDeleteEmail}
                                    selectedEmailId={selectedEmail?.id}
                                    onRefresh={() => currentEmail && refreshInbox(currentEmail)}
                                />
                            </div>
                           <div className="lg:col-span-8">
                                <EmailView 
                                    email={selectedEmail} 
                                    onBack={() => setSelectedEmail(null)}
                                />
                           </div>
                        </div>
                    )}
                </main>

                {notification && (
                    <div className="fixed bottom-5 left-1/2 -translate-x-1/2 bg-slate-800 text-white py-2 px-5 rounded-lg shadow-lg border border-slate-700 animate-fade-in-out">
                        {notification}
                    </div>
                )}
            </div>
            {/* FIX: The 'jsx' prop is not a valid attribute for the <style> tag in standard React. It has been removed to resolve the type error. */}
            <style>{`
              @keyframes fade-in-out {
                0% { opacity: 0; transform: translate(-50%, 10px); }
                20% { opacity: 1; transform: translate(-50%, 0); }
                80% { opacity: 1; transform: translate(-50%, 0); }
                100% { opacity: 0; transform: translate(-50%, 10px); }
              }
              .animate-fade-in-out {
                animation: fade-in-out 3s ease-in-out forwards;
              }
            `}</style>
        </div>
    );
};

export default App;
