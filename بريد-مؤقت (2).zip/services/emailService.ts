
import { GoogleGenAI, Type } from "@google/genai";
import type { Email } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

// A list of plausible but fake domains for temporary emails
const FAKE_DOMAINS = [
    'mail-temp.org', 'tempinbox.net', 'dispostable.com', 'fakemail.live',
    'quickmail.info', 'trashmail.ws', 'burnermail.app', 'onetime.email'
];

/**
 * Generates a single, realistic-looking but fake temporary email address.
 */
export const generateAddress = async (): Promise<string> => {
    try {
        const prompt = `Generate a unique and random username suitable for a temporary email address. The username should be a combination of a common word and a random 4-digit number. For example: 'leaf6831', 'river9102', 'stone4829'. Return only the username, no explanation.`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                temperature: 1,
                topP: 1,
            }
        });

        const username = response.text.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
        const domain = FAKE_DOMAINS[Math.floor(Math.random() * FAKE_DOMAINS.length)];
        
        return `${username}@${domain}`;
    } catch (error) {
        console.error("Error generating address:", error);
        // Fallback in case of API error
        const username = `user${Math.floor(1000 + Math.random() * 9000)}`;
        const domain = FAKE_DOMAINS[0];
        return `${username}@${domain}`;
    }
};

/**
 * Fetches a list of fake emails for the inbox.
 */
export const fetchInbox = async (emailAddress: string): Promise<Email[]> => {
    try {
        const prompt = `You are an API that generates fake email data for a temporary inbox for the address ${emailAddress}.
        Generate a list of 0 to 2 new emails.
        Each email must be a JSON object with 'id', 'from', 'subject', 'body', and 'timestamp' fields.
        - 'id' should be a unique UUID.
        - 'from' should be a plausible sender name and email, like '"Service Name" <no-reply@service.com>'.
        - 'subject' should be typical for a temp mail service (e.g., verification codes, newsletters, welcome emails).
        - 'body' should be plain text, 1-3 paragraphs long.
        - 'timestamp' must be an ISO 8601 string for the current time.
        The content should be in Arabic.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            id: { type: Type.STRING, description: 'Unique UUID' },
                            from: { type: Type.STRING, description: 'Sender name and email' },
                            subject: { type: Type.STRING, description: 'Email subject in Arabic' },
                            body: { type: Type.STRING, description: 'Email body in plain text Arabic' },
                            timestamp: { type: Type.STRING, description: 'ISO 8601 timestamp' },
                        },
                        required: ['id', 'from', 'subject', 'body', 'timestamp'],
                    },
                },
            },
        });

        const jsonStr = response.text.trim();
        const parsedEmails = JSON.parse(jsonStr);
        
        // Ensure the response is an array
        return Array.isArray(parsedEmails) ? parsedEmails : [];

    } catch (error) {
        console.error("Error fetching inbox:", error);
        return [];
    }
};
